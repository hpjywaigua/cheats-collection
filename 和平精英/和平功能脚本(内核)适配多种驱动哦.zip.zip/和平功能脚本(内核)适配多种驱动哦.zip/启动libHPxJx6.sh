cp libHPxJx6.so /data/local/tmp/libHPxJx6.so
chmod 777 /data/local/tmp/libHPxJx6.so
/data/local/tmp/libHPxJx6.so