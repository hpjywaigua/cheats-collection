cp libHPxJxXFST.so /data/local/tmp/libHPxJxXFST.so
chmod 777 /data/local/tmp/libHPxJxXFST.so
/data/local/tmp/libHPxJxXFST.so