echo "\n"
echo "自行给予Root权限执行"
echo "不给予Root执行不会有效"
echo "无Root可用adb shell解决"
echo "列:adb shell settings put .... 0"
echo "\n"
settings put system block_untrusted_touches 0
settings put global block_untrusted_touches 0
settings put secure block_untrusted_touches 0
