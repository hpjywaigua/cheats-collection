/data/UK
chmod 777 /data/UK
