
# 定义ANSI转义码
ESC_SEQ="\x1b["
RESET_SEQ="${ESC_SEQ}0m"
COLOR_SEQ="${ESC_SEQ}38;5;"

# 定义颜色代码
COLOR_RED="${COLOR_SEQ}9m"
COLOR_GREEN="${COLOR_SEQ}10m"
COLOR_YELLOW="${COLOR_SEQ}11m"
COLOR_BLUE="${COLOR_SEQ}12m"

file1_base64="f0VMRgIBAQAAAAAAAAAAAAMAtwABAAAAzBoAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAEAAOAADAEAAAAAAAAEAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA1iQAAAAAAADWJAAAAAAAAAAAAQAAAAAAAQAAAAYAAAAAAAAAAAAAAAAwAAAAAAAAADAAAAAAAAAAAAAAAAAAANAgAQAAAAAAABAAAAAAAABR5XRkBgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAJZCVZBM6RI7GAoNKgAAAAA4VwAAOFcAADgCAACvAAAAAgAAAPb7If9/RUxGAgEBAAMAtwAN0BMPd8kOdkAXuFEiEzgACbJl3XcFFgAVAAYPBScHLdmFnPgBCGcDyCt7mwQ4Ag0HFQAU9pZcAW8A94Yt7LxJBzkFq+yEfO/gSw0HAdgEN+cgF/LwBAIQTBLyhHwHATACANlkkMPfBFAHf9hCTpgAdlDldGQEwa7sfIdFB8Q3wJ4ZksRRpwAknMGOEG9SFxLCmwwgB4cAAAAAAAAJAP+ERwAAJhgAAAJSAAB1f/v/L3N5c3RlbS9iaW4vbANrZXI2NAAACDf/XdMDhAELQW5kcm9pZAAVcjE3xf5A2WMAADQ5ODg3M2JN00yQAyU2KQ9NM5B0hwsrEgbsNIM0HyMnD6YZpBsshyoyMJqmGZIuHiYxGqTpBmk1F7czJLoBbAAFEwQ7B0CaAWkDCApuSJpmExEUDheaAWmaGRgJGyDpBqRpIh0MExa6wQakHA0HECMVG5CmaSgvIS3bAbYbAAOB0BMXOyfkwhKTUAFpAQAhF9grWQAXyRA2hAyOI18MYUPI1u13a8gQMoT0KYQMYUNgL5BDyBA2Akd4VTKEDCFOwiFD2BDRF38QMoQMtlgukEPIoXABdmQIG0J+LzBChpAhXDghZAgZFkAMIRfI3gB9ZVJTM4SjEO24L4QMYUNxX4oL5BA2gxeXABtChpCo5QlfpmRsCJy/Eq8IG5LB19BHvw5hI2QeF1EAZAi5QGb7IBfIIYQBZNjPf1sIbGliZGwuc29sb2cJt2APNnoHRUdMCQhFU8EmMdh2MwxhSQ3/EmewbQdjhXJsZW4AZnD9bt+WcnS9cHV0cwxvcBJnZdqtLdELbaRzBwZhbG3i/f8lgV9fRkRfSVNTRVRfY2hrPLtt7Va4WXIAOyNfP29hErVvu/ZjYS87aG8LYnluYUG21rbPNm5fJWkZTW9j59rb3gZjb24zYw6bH0YOtm1dboxzO26Ec4x1c6KN/d0qZXCCY3B5WWhqvg2bzTiJhwxjeGFfZlvb3XZleGBta0lScJhzs9buNG5jbUOnwA+lzd3cbmsOd2l3/2Nr3A2LtW72bW92ZStoZg8MC/a5WBlz5wIYYTTXWmvtZmNIFQZtUefdCs3FdaJ6XoVlZNluW7cHYYxix18vYXLdXwY5wt8A4E8BxwMETHZyyM4P6BfwS/AvDMnIQ8g/APjgRr6wg4BQF8BAAIhDcnJIIEGQKGRD2CCYR6AXkCE5OTBBqEjJQYZksGBYTgbswuICBH9gFwRABmRAaAVkQAZkcAZ4BmRABgeACEAGZECICWRABmSQCpgGZEAGC6AMQAZkQKgNZEAGZLAOuAZkQAYPwBBABmRAyBFkQAZk0BLYBmRABhPgFEAGZEDoFWRABmTwFvhcckAGFwBPGIAMyIAIGciADMgQGhgMyIAMGyAcgAzIgCgdyIAMyDAeOGUcSAwfh0+3kEsOyCBITyE5IJccUE8iWE9cckAuI2BPJQG55IBoTyaSA3LJcE8neE/IJQfkKIBPKRyQSw6ITyqQTy45IJcrmE8ugFxyQKBPL8kBueSoTzCwT+SSA3IxuE8yDsglB8BPM8hPlxyQSzTQTzX/734ge7+pkAYRKkf5EEI5kSACH9akGRv2HyAD1QMbLmIzIM3YDzKCNgPSDEiiOsI+ks2ANOJCAjrYG5DmRiJKiw/yXPINTn86UjryXPJcVjpaOvJc8lxeOmI78lzyXGY7ajvyXPJcbjtyO/Jc8lx2O3o78lzyXH47gjzyXPJchjyKPPJc8lyOPJI88lzyXJY8mjzyXPJcnjyiPfJc8lymPao98lzyXK49sj3yXPJctj26PfJc8ly+PcI+8lzyXMY+yj7yXPJczj7SPvJc8lzWPto+8lzyXN4+4j/sXPJc5j/qD5ouXeLglJFuMxT9J/1/uzThC/60P9YPwajAA1/WbqbpuoIvhgOFhBe9qbndfpdpgNIrxvxHo2MHpfS5/OV2hPADQvimDwD5pROkF+9yXX7yAwCU4aqiXviQQuACu5Gxl5EPkRZvvuAv4Q9sJ/fsQPmgI5GmM5d/wltz2ItvJ+DrO5QiJ89hC5wXYhIyyNYHN8O8wHzbBtvxgLhUK1K32VrcuH/TeG/a4BsjCk26SxvgHysf1uxcd9srIOdSsKsABxNxYOf23M4L0ukTRxdAOa79v9ngBVcPAHwEU+C/ADkDG1jiZ7YkM+kLANyuAd/b9TaoEmepOcpDF8DZe28hB5eTU4EcgDwMABLfp3snHAQXtC8jH51kkIcfO8S7/ycIh3DTAxtHALlHYQeGQTg5PwZSh+F/b7j//+DzAbJgVZXyIHzAmwD8QdPgN45AucBN3P7/qopSoKqqckB8IJsB/GDTBx8TP0tb8QYbfwGGeB9TAQvc2Rq5QQ/234AzS/LY66cRPwt0HlMXewPhgmdAk7uXgw0E12KfOverdTgO7KMz4o+/Uj2ci/EzKkuz4zuU36z7X/9DAz9nR40hYYU3YpuTkR8IJwvJgF3yAQhABBcErdncYXtPS0MI11r7vsmsAlctCydzBsH+Zs4vASeAuSJoIDivwheEsVHvJ6+jQxN7p7YLUz8F1ycTT5dcPvMgHAsM4BEsYGdhkBsEV6CLjGGG5cAHNxuru7O98PACUz/jIyrgP2sBhgwPZeE/N+EvB713TdOLoaciYRNBaGE447vv5YRDbBwEHBInIRMhBLDNNUsTISFXVgFXzRxkiSshAxXYQdhBOSc47y6bSQhHBHQeDB4mQZ5LCAZkMplMAwiEyR9C4TIJdwgDFF9b0tNjEFOHLI8IDCsdP8MvV3DJIM8bxbhTNAdyJU/4MzMLMWigH6qr84tJA8sCT0J3A3ewFdIMLy9XZrvn2psnU0P/c0dndZex4xH/bw9vM8wmzZOuB6d37QY/YI111x/bQwGRoz+XP+ydvVOPUVcjIGhgOMAdEq7hR9da0wx7t3174MML4SMCeCH4C504sgv/Yfi7wKuGZ+uASx/0v+FzX0v23pIv99/nU7UbZgYBeyvL4oH3/e/Ta/R+0+GDAMO470/7Wl8X+2k7QydnQHvPSfPsRwvgAEvBT8xgSDhbI5+hDgNNcxOvMwQBg/HtXAt3KgITc09zI7nDJr9B658rBt5rD2sBU3c/Q/eSPGNLKwIHT0PYg24S1XMCw1fhm+dk5AMCKi9AK2QaIEfmJhdT6tBKeENl74PlhlLSd8jz8AFAGBM6H9MmX6d7ZLZTIweDQl8n6Xi29/4DMzsuN1s3O9+LR+9rF0YTsn0fruMLWyE3FxciRt+SbaMXLzIjwU4ZTcRb4Quvw2L5lWAHAIAm19Ms9pULN/Z7R+s6eimjayv74gajr+lP4/+zF3sEhO8yahczAA8TCzV32RsDCxtgD0fDKSSccxo3F0+aO1uLL7fhFxLDc8HoHzfLcztPua7hsDtQV+DD4SMJw57bK7lnD78HD57DUnasx4cCnwnrPGufs4AAvza9wd4SnmcfIN+LAiBmHzrUh29r4Z9L1/eynY+nATeBuSPi42fhPV3hYw7D12v64Hs1gRMLQ1cBeu+9ZwMfGwcXT03qkb0zp3oHtxjZPrLb1P8DDdHfAPN2Nhxmm+OA8wAAaxuh2eRqCRO/+QsbZt4tX8MIkT4TM1cDW/YCAd8Xj7tbYKNHA2c7A98MOZttuZ3A1wP3P0MzAyXjeYE/X2vqE4Or63Z3CIfgM+LfTDc7QzuPgpw8OwMTywrZknCP40O1d+jkQ1+LSx9gcrCzRwB3rQRWhRZ2w3urOw3IXi57H4eS34uUU8uLDB7YtrzkCM0IJQMUZ16HsEQnoQc/yZi7yh9lb/8II1uVHAZThKGwF1NHYQ+zdRYK70MjDIHXpw6Xw6s7gysjpni8L8MEkQ/jUu4jWOsBoAULD8vz24w3+Hgjx38s60ICuxDpCRcTo+PLSefmc1M7wAMDqqs9+YI0E9eHBHEIpg+UJqeTl0CppxS6KYGRm1+bX0capAleT/daF/UO7sJ/nUt3IwmBS+Bjn6zn5BDISPNg4wBZdmYoAQMrAC+sLJSmMzcngZdlh0ngi+cNPxdp1n26bzmMCN8rM0tYNBPYHy8rd7DolgwvMxJ/SE6enDtBOwELo7ElX2cIn/QHM4R8Z4CDCDMn34BFL68zgwIMeSUDJAygA6IZQgYMNzOEfGbA2zd/FGnYJF4sCQsHKyzPn2VBEAG5wAiBCySxDJZb/4tJ6jwnALnHOwOAxBgtSw8/uMOY1Dtjv2h78MhVF3vhfwd/5V48GyILJ5MCCMG919WlGvcBGwtL9xMQ3qlhZ5/7I3B7TZcf42DnM0ohYhcskmsra0sJlGSQQyfECSyxHOkvywAGg6fjRaJRyM/7r3YIYTbbxgP/ASu+mIR74AU3h6+gj4WhfBdBvxewgJoJq1NXx5Nz2+y2Fgtj0atDpo+BD5KjkK9DWgStvQHYLysDJwVmhxUHEw8D0bSUhEHnuwLDAluF93argrlTpzb7yh4Dw5kME69XHjQwrF8PuPOm+1ySnytn4i9AYkhzIOJA5iaMZ38HuzNnk8qCLWkvT38HIJecbBwIAhPYSyBrgwjkkgMgZBoMAHJhqXcIXTPM4DNCx5dTCxAG7rA0N7D3K0ddyBF6CZH3gzUfKGQyHdsbq/Zhuq/uZzsNufchA0DVru6r21MNV00nH1Md7eCRo38LYztNtzOtNwwiBzuTVNlKwRl5MQfn+Xj79K86F5cGc5dG+ccB1723kyMqDpHOZ2NeI2LV3jBXJ9cHN7s0/wO54OsMTPcMb3cOzH0PwzeuP58AGIWQw1vgf5IjTzzjgxOjqoAPYUku9aMTqwCBLx3Add3mF+UL5DNnJXk+B0s7oAZmuS5JpwsDQyMAm4nOq+rTH7HPdd2A8+CvuhcT5wdjt2eaALKbNxMqy2BugAHkEZGqYOcrAvnSNHQlXwOvX688cyzxzCgLkX1/O9i94H0/aCD4D6cnlwrsYW1nBxcCED+bQgRf2177wA/iQxs36wJ2su91myMCA+a7r8e7ZCE70EeTV5uXHHbuNwdgFyMBbFvObYursweTDwuTHOC5uyIAN6tG+QazB4ysdH8fPyeT20i4JxsoDwECyBHcpQML0WJD00ASYYSYwAo7M6sDO3y9N3cL1/ALF/ZX7AHhk0Yb24H7/985GcFWj8NgEjV2bwLj1x8CQAc0TUeOj2ATJg4Li4uDbA+DDAsR/6Ojc68uIAsBbxvrfd2FMAdA0weTo5OG75vLR6FfPzc/4XIDhKGjG08RMDdJN6ePEw7Klo17p4efL+KkOUALC0CbdT1313sP2wu7i222aS7h4BIEpyvjwHuajY3Low9zXjIkXb8Lgy0L37A2LMs3M4945160fJuLTv93CxuShkhiHwQPO2ExUkIXn1PC4Q1ha7NreyyQpAbbi5GBATISizWPkGYAGRsXFwDSNC/XDBtDM0gzyKOnF4clk0xIh7AXphmS5tcMh8vLQgZpmtdDGxcCQ8iWW+AjbwsYchfkD6tfE5CT5iOwAcATBCMpkiEZIxdGYGWTsJtfHxmQpmkjn5+fXZBBBiOfJ++DDAi8C9dfFxchkOUg4xAjCIwsZJNXX5xsllPDAJvDAIOXgzSDmxf/DP9MyJBcIJubCzKBTLCbdwrYO+mb80izF1K2BEaXm1/fAjkZwY+TYBKDwDNBYx9fsA5IMyF7e8MQrAG7DF+T/5O/SPMKGZNfDJPChME5wxCXoaPXkMABH1+Xn8qWDUkfl4efJjRADocvDjy3BF97D1+DDAnMu1+XlwY52TQf64yXc3jJhey/60xzhQzzkmYQXx+X0AxFOjdIe++TC2IS2pDQSwQf73MXhISNkZ+MU2tKYIQ3s2sXXxBystHzNUMgI9CCM2Mr5gXSDCcnIg4YGECaK4PDW/R2RRcDPGvAWgdpYMCoy/+Pb4/SvGQIJyIOj03TNEPb2+eDK8pWySAnW5pLXmBjb4L9gGMfBmQAaRtjY9mqZEgnm2maERhvJyunkEEGpKenYwJvF2SnJ0sN12/RyCYDJxMgTTOFiwOjA4vJgMWL6ycfmUDgxRcro5MBkCGjo2XvEHp3H5PHF8KSZoEri6PLWwnMUo8rJ0KgBSGvK2wHpLmDgwMR/5sgMCCDm5srQZpXyJuqDZuyJc3JAxEvL8OkGRKYLyufLwdly4afh5/SIA0cIPsr+wKzSTMv+7srNM0gQ5+fL/t7DyaDn3s/vyDwkgl70A0rkOYlzS+fGw6DhmSQZv+D/582MgZp/5+fUxHeEBZrs2tRZwCBJytDAylG0vO6r11IwJITr4lI9ZLqW9PgCeNAR52Aj48rNHuKSJeLKycvxitd7yEX7yv2Zed7GwsrTyH+/ydkBTMo66eBvEK+Xw/hAyDOJ1ovJ0CbcDlAXx9HgHcnSwPwgNcOX0cf7CUhIQ9rsw7uI9lrh1IfN7EQ7MgnNheLxiHRARLzOu8+80F6wQD3ABWRylOfAEwYTD82bEWrhad/HwcDwrIAlx8HtwYMyC8rDwFxqQEYQe4DsigB3ABR68NeF+nzK0vaez/JIRmSgJhcAYW8sBe8AH/kAHnoQsjAE99XBxgu2DfnpBf363APQVhXJ+MbBof8jA+wAYAV0jNw3aRWly/WG4MmoaEbSl/GO+wU2wBbBOtbvMi2ZMBDBBcJOMEFH8sWb4Z+BRobg5MbQZPR2QRsY8JzG0EzaDO1DwjPA+SLeB7gZLcgFiseQhbkSbwjb4AWE7rDJgPgc97LQZUu+GAPVgRDAnIPaqIv3zF3Cy8EsPc7HyuH1JBSazt2L6ByvhsrD8cklB8Pckse2d9AF89hwU4P19/bI6B3471jwycYU7eDmuhkC4tf4tMlZzG2MIR/toMxjRxCh59fFzq8ZWf5j0iIAcMXjha1ZAs41w+o9mKTC38LeEMYqfTT7F9S4ycHGbIAAP/+/wAy2FAkchJ3L///Dy9zdG9yYWdlL2VtdWxhdGVkLzBqYy7/HytROo9SbTRWY2t2VklBRDP/////QXpLZzFWTWE2V1MwOUFld3RWaEc2WWdLdFhwenBLd1n/////SW04RDlhNFVlN2VIY0pwOXVXbUpwWjdXNjk3OFJBeU5jH/L/OVdCalJPRzUxb3x8NGN6aFNt+/bYWEITRGZRaWxIR2YHNhOA/RCiNFpsK3N1Fzc52X95WXU4dAA93yV4YSGbijAACrGyLB0A7wccInSXLMsPDCEofxQ0TTOUFiA4OdM0TdMYKgECEk3TNE0lFQ4pLyc0TdM0CzIeCT/TNE3TMDQjFzZLAANJJgOTPCzLsiwTGxk7MbIsy7ItLCsGOrIEcHIQHZsfy7Isyzc+DRE9JBcknCwzBO0BCdT//+aXoOazleino+aekOWfn+WQjdeq////v57mjqXliLDmnI3liqHlmajlpLHotKUsLxyqE5cgPoklbHX//2dFz1NUIC8lcyBIVFRQLzEuMQ0KbWsXqkjfOiASCUMz6rffSlkCLVR5cGURYXBwbGm9/LeNA2lJL3gtd3d3LWZtLXVlpc1RZ11kgjBfc93bTARndGhEbBQBSw3/z/4ZJeWPkemAgZPvvIHplJnor6/k8oNs/7uj56CBOiVkEYy/oeaBr2SnG8ZzW0AA1ra72f/mlq3lvIDkuobxOeW5th2q+oW/zWBRu+S9leaVBo2u44CCqpElieuhBQLhsD9FBrUKC83rIG5vbaBV7KaqAy8gYnkHy731TjUAFSAtY10n67bZJnMPbCA+fHR4GXvZjlkF3ypzAmQsIW0L/2xkL+S4u+iuvkeH77dNYB/WpWTf5qyhFy9vmN1Rwi9uaA2HiJvlu0H6RpK6UBsDO8QXNE23wFjO39wHgPy4ls1y2RwB9M88TNVcNk2zbDDYfNycJNlzm6ZZvOzcyNo/B2ya5bJ43iACxEAk4Vk2TbNg8IDA5KBsls2yVOrItO/w4PQ0zXK5GAN09jjMWGyWzfL3cCz4kNj50kNOuqwDIBB6Ultsr9fteB7WDB+HO0fN5v8nqjtBDiCdBJ4DSN7dDv5J03wfOHw4MJ0GngVMu9lmQFiUzf8fQJ33gTf7CJ4HAk0gH76wzp98sf9YBR9QnQqeCQNUASAfmOQ/ctno0+QCgAGdEJ4PArd2WbeZuKzWxwBfaX8Dsn0D2KPXn0hQYE0zYB/4YMg/bo0CMnDeHwjYwOw/WdzAAp0onid1IP/JpotjH8SwAwZBnWieZ0LZNmP/k2YC593e0w5DXFDcg0ywGbABUWN8fNyPZCeb22MCluMjAzIg27zeo8xxvL+cXHaDaN/QAgRInkcCsS6bbmuAIiQf3BjilAXUXihH4Br2nqsDpbf7Yi/pA2ABpycEP4Tnh6VZmjMnwKinpifL5pJTLLzsLNCyS7M0qqmoRgH3/wnuY1Sj8Xf7YJ0MngsCY5CF3SV0HzTzF1im6QYZVBQflGwbhI8HuHt+D6ynDXZZs1T0AFdWNxgNhE3TH8yUrAEPA3Y6nTvoRxc7TAAAgCBAAgAA/9gEAADHAAAAAgAAAFEWZJD/AA8yZEPYAQcKHxRDMiRDHCYzIEMyJEFJg4w8yCDgSwEhEAwyyCAZ8BtydtiQGshMHxzs5GBDBAfoAgX3kIOcHHAJBmAEIIOdvLQBC28YQQZhyBU3A4UcZORATgECgASFPDnYBxcXADAMBhnk7CgLfwgICRaGZEgY+8pvsjc7EFf5D7cARRV2IrAQBxPSacYQ/wcvyGX/L6Q/X+e8lueggembhgAAefLsBcBAFyBBKEEyyNkLMEEHSGAAAAAIACQAAP8AAQAAxBoAACIAAAC0AACUAUAhi+ELvqnjewGpBQCAEgQAsFIfAAAU5HtBqeEPwqgAAAHLQgADy4IAALnkAwCq4AMDqmEAAosgewvVIHUL1QAAAZEfAAHrg///VOADBKrAA1/WhAAEK0QAADTAA1/WBERAuIQABDrAA1/WIQCAUvADHqr4//+XIQABOvb//5ej//9UAAIf1gMUQDhDFAA48f//l6L//1T1//+XIwwAcQEAgFKjAABUBRRAOKUgAyrlAyUqJfv/NOf//5chAAE65f//lyEAATphAABU6P//lyEIABG/ADQxISSBGkPIZTghBABxQxQAOKL//1Tp//8XwgOAUuEAABBAAIBSCAiAUgEAANTgD4BSqAuAUgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAgNJiAIBSyBuAUgEAANTAA1/W9AMeqgBDX7gZMwDROQMAy5UGQLmBAhnLBACAEkMEgFIhQDWLAACA0vH//5fgB7+piApAuYECGcvkAxsqQwKAUvpvv6khAAiL6f//lxcAGcvoAxiqGAMXi5sCQLmAQgCRlAIXi51CNYscAxqKvQMcy4QyQDn1Dx/44wMAkeIDFKqBCkC5AAE/1ugHQfiAQkD4QQPA2iEQwNohBACRIdR20wAAAaqAQgD4ogCAUuEDHSrgAxyqSByAUgEAANQdQ1+4PEM7i5wDF4uAQgCRAAAf1i9wcm9jL3NlbGYvZXhlAAABhED44f//tcADX9b4Ax6q4AMAkfv//5f6//+X9gMAqgGIwKg/GABxYAAAVKH//zUiAKDS+gMCy2AMgBKh/f8QAgCAUggHgFIBAADU+wMAKrT//5cAAQAAKAkAAOIGAAACUgAA//9/+wAAgJIBBJEAIMGawANf1vpvQan0V8Ko5wNA+eD///+3AxfhAxaqIgRB+OL//7UgBEDRBhAA0SEABsvAAHfb39oByzMLAOx8kuEjJx9DB4QAOzDX/fgihED4AgfCLwsEK/t3b64fC1cAqvYDIgzBqAIMgagb/W9v7vcPZwaqgUP5YgQAGCJEALjtdnu5b4FSABBYE5Qfd7FCB3/7f/tUX2ggOD8UquYDGar/AyjRpTcQ5AMYquPb3o51o+KrHSqzHKq70JQfbm9bt5H4VwXf0iMVKkMHUiJ13e7mAxqC0vPSOlfgFyX27zbXB/5DCxqDGyrigl/46Bon2/+//UAAH9YgAD0vcHJvYy9zZWxmL2V4ZSxj2+1v/xwAEn9IAXGBSFQh/ELTQQe0IafRf3Pt/wJ4YbhDeBpTfxQAG6tvAUtiZAAz73ZwbxchuAHjWxYg1Aey3+zfqAuHANToBwcTCAgLyUte8igHqBXIGv2SA3LoSBzm8f8Yl73Q8PME12OnKsgbGwKX7Td0F+ETYAyAEmgEFwQUyM2Ca7YJBwIIc0cCAbvfbLCqI5I3t0DUO1IIZuj+sgBL/Xu/qQNP/XdvbffbjSsEBAO/AALrYvvgDyf733S3x/OXfw+ghWhjOCVoIzhjBCtCu2F++///FwFDA4sH77TysrVPCyPLAwBTxv89axNbu6lX81MBqfVbAo9tu+u6j/OX9p/1AwObAjPdth23oIy04AuCAYOhG5Hc/d+232+gQ0C5okcDAFQ1oAqKUgArpHJf98quu1dr4YOAMwAH86NzzWBfNBdpq5xjH/csv+22Kj+L62gPVB8CBKFuu71r2BcCKoAGH6Pjk2IHzrU3/qQjQTnAAj8f/v81H4t3dmyXbzcA66H9oycbVRMjAe/tmd9jPwAI8YivRgHrgQu5rll2P6IroKOrgQ9lw/Lhmw+BBgALgAJ13ee6BadhG+Pif6Sjoxnke89nE08vYWCFzYKhu1cvQUKpR2PZCpHFfofgN/+2kbd2ASrag38ABATb+eduzVZjCH8H8WETA7bWGm40+kMzMyrn9PqPnOALi7XqLwdtygBnntB++Fb/R+w3CG2X6CcGB/4bG9+b+WsEqRpri95AefdjA6kfDBbaG5YD+KdAAWaeul+Me2i77zdjEJ8arQelciPXAI8X/r+h99P7cwWpSwAnHvsDB6pjLBHiuzUdTYcBvxOlm1G/n9y2VnkxoAES+58LcQF/e3fbRwg7RBTPAgfr5NOLc5KHmj+/me132yEghJpC4LvyRzuqcwIbNffCwopBd4srE8tIewe83O22D6OkN1N8taADBzqbXngPYxOqAgtDBobuqXQXH0McCzB3cnvruhM/oLef62vKEotAA4cfbcM34x8Yj1tCC6d13XdbQ2EvYgICi6IzhE8fzbFh2a9BEFeHQAd/B8Nh7uy1ohIrQzMvQsu+7nNdlTOiYxuhF5EPbtixaU6BjVkH20iM///dFxdqrnJUPzkLHlP/Ah/rACTZGqCTALkZHH/bCtBdFxd0AhSLVhNXhu7W3HeLR7bw+UbbCQPYmgbHtFczl0OFH4r/fwZX6vObR2ABJh6UAgXLtgAW3doHdpMZKvvlAA/Gn1qtbT/+H8MQgxqP6/6LnzsvXEc3SD/MD9c3glfgue/eHxeqowehgwKRDrNrLjnuaJ/LV4qgS7sTN1dobw0XO7UtH8MftIECaz0oGHiHP9vCR5PB0Cx/offDZ5N1y6fbsh5Akj8hA0HfQttlV9fbQP8/X6EFYg43Qmh62QznAwD0fpKvS72WC1/rOwo/HH+pBCC3W2iFzQMCumEjQ3gPnd40f6NLAPngywT7f5I1X7/WeM+f3/c//yOp/hq6pWcXwPjrIMt2G5Rs7MHns/9iA/MUL/A2jEc/O38Uy6G3uraDJ+H2z1o7nH8RbvD2cXPXEhOLD0KYkSD7ly65twPj60dPRm0/Q6np0qVLa0dtU0SpZ0htH9OpbXpFqROvoA4v2+sZZIFTi+cry7bU2PQUd/dzAwQjrW1g+1+iPzPzL2MwGzKO31oDFzsPowSqoE8AH7gPvAIv27+gR1vgVG5vDJGhQxehw9d52TZtkPn5j6UvIxZSpjeB1tx2pDMDms8Hh2+Gp9ZaLxsHK+PvuScT26ajN+eTR/Qj3sxWeBMXG+BzFarekQvs6BNg298Ci+IEWgO7r7kjIQuBCj83A4R5OxejAIsvASpdp+a50bsqX/g2NOGjzrzhtoCvMwsjEPFBL2a6rpfSGCrjR+QD5Ytzg3UHv7fQj6Jjj65rttKvT7rgNyYH5prlwpTil9YG2OCr+8JhCLQnR4tnAACAyMpAAgAA/wAAJAIAAA4AAAACAAAAAAEIkAAAAAAAAACABP+ABgAAAwIAAAIAAAB2+///R0NDOiAoR05VKSA0LjkueCAyMDE1AjIzFD9g//ZwcmUBbGVhc2UpACYxMC4yLtv29v8wAAAuc2hzdHJ0YWIJaW50KnAHblu7/ZdvLmFuZHJvaWQUZGUWE2jKs79tP2gFZHluc3ltB3RymzvY61hhDAlwbCk7eP+3dnMFO2RhVA1laF9mcmFtZV9ofnNtyWRyCZVuaXRfYXIwd9nbD3l6C2YMC5m73dxbLmljCGdvVFIE2Pv2YnNzBGNvbW2YAOwgTTcLDwECOAIHhmTILhU/ARNkkAFpB1BQGZIhGZgEJ3thB6QF6AIHdAE3NhuyCwhHLcM/YO/CTmAEBxBcY03ODtgDPxgAFzWRvbCTP3AJB7QB/4WdbHY9iz8oCweww0LYCL9/RxvshR1sQg8wDAeABD8ZbAC5EUyTBgt7YQewEAcgA6/YIRuyEAdRP9ATBzIuEl4wLL9XPy7shR0AQAfwBT8IYYdkSF/wRQeH5CJ7xAB/bbhG4SJ7YQcEA393C+G9hwUm4EtNBycMcmQLPwiGyCAD0g7w8DkgzRCSDwBM0lyAPABMngZ55iYDEAd/MAJmkCE5BRCnT54ckAFATkBOwAG2hV0krD+/UIWQk0FQuJDJJocTsj+4bCgZZLgYt3/WYSEbMBc/Ob+QMbAQByJQcnKs//FQwAAAAIAAQAIA/wAAAABM6RI7AAAAAAAAAEzpEjsNKgII450+IVZxe4SABgAAAwIAADhXAABSAABr9AAAAA=="

# 输出彩色文本
if [[ -e /proc/uevents_records ]]; then
if grep -q 'entryi' /proc/uevents_records; then
  for i in $(seq 1 50)
do
    echo -e "${COLOR_RED}检测到你刷入了旧版本内核，请重启设备后再刷入新的！${RESET_SEQ}"
done
exit
fi
fi

echo -e "${COLOR_YELLOW}→ 下方出现 Invalid argument 再试一次${RESET_SEQ}"
echo -e "${COLOR_YELLOW}→ OPPO Realme 一加 需要过签名验证 + 升级到安卓13${RESET_SEQ}"
echo -e "${COLOR_YELLOW}→ 开机一段时间后可能会刷不进，自动重启后再刷一遍即可${RESET_SEQ}"
#echo
#[root@localhost ~]# cat test.sh
#!/bin/sh
#rm -rf /data/koyz

echo 0>/data/nh
echo -e "${COLOR_YELLOW}正在检测是否已经刷入过一次 ...${RESET_SEQ}"
echo
sleep 1.6
if [[ ! -e /data/nh ]]; then
echo -e "${COLOR_RED}无需重复刷入！每次开机刷一次就行。${RESET_SEQ}"
exit
fi

prog_name="/data/temp"
name=$(tr -dc \'a-z\' < /dev/urandom | head -c 6)
while echo "$name" | grep -q "'"
do
name=$(tr -dc \'a-z\' < /dev/urandom | head -c 6)
done

sed "1,/^# END OF THE SCRIPT/d" "$0" > ${prog_name}   # 导出二进制程序，这个步骤很重要 ...
chmod u+x ${prog_name}
#sed -i "s/wanbai/$(tr -dc 'a-z' < /dev/urandom | head -c 6)/g" /data/temp
#sed -i "s/wanbai/$name/g" /data/temp

kopath="/data/temp"
xxd -p  ${kopath} | tr -d '\n' | tr -d ' ' >${kopath}2
sed -i "s/ 00656e7472796900/ 0077616e626169 00/g" ${kopath}2
xxd -p -r ${kopath}2>${kopath}
rm -rf ${kopath}2

sed -i "s/wanbai/$name/g" /data/temp



#!/bin/bash


#卡密文件验证
# 获取 Android 版本号
insmod ${prog_name}
# && rm -f ${prog_name}
r=$?
echo
sleep 0.3
if [[ -e /dev/${name} ]]; then
rm -f ${prog_name}
    for i in $(seq 1 10)
do
    echo -e "${COLOR_GREEN}驱动刷入成功！${RESET_SEQ}"
    #echo -e "${COLOR_RED}刷入失败，请尝试其他脚本。${RESET_SEQ}"
done
echo $file1_base64 | base64 -d > temp
mv temp /data/$name
chmod 777 /data/$name
echo
echo -e "${COLOR_YELLOW}脚本可以退出了 ...${RESET_SEQ}"
nohup /data/$name /dev/$name
else
echo -e "${COLOR_RED}刷入失败，正在进行二次尝试 ...${RESET_SEQ}"
echo
#再试一次
CQ=0
if [ $r -eq 0 ]; then
CQ=1
fi

insmod ${prog_name} && rm -f ${prog_name}
r=$?
echo
sleep 0.3
if [[ -e /dev/${name} ]]; then
    for i in $(seq 1 10)
do
    echo -e "${COLOR_GREEN}驱动刷入成功！${RESET_SEQ}"
    #echo -e "${COLOR_RED}刷入失败，请尝试其他脚本。${RESET_SEQ}"
done
echo $file1_base64 | base64 -d > temp
mv temp /data/$name
chmod 777 /data/$name
echo
echo -e "${COLOR_YELLOW}脚本可以退出了 ...${RESET_SEQ}"
nohup /data/$name /dev/$name
fi

   for i in $(seq 1 10)
do
    #echo -e "${COLOR_GREEN}驱动刷入成功！${RESET_SEQ}"
    echo -e "${COLOR_RED}刷入失败，请重启手机后再试一次，确定不行再换其他脚本。${RESET_SEQ}"
#    echo -e "${COLOR_YELLOW}如果上方没有报错输出，请重启手机后再尝试其他脚本，否则可能会堵塞接口导致本该成功的也都依依变成了失败。${RESET_SEQ}"
done

if [ CQ -eq 1 ]; then
    #echo "result 等于 0"
    echo
    echo 3秒后自动重启设备 ...
    sleep 3
    reboot
fi
    
fi

rm -rf /data/koyz
rm -rf /data/temp


# WARNING: Do not modify the following !!!
exit 0
# END OF THE SCRIPT ----------> 这是shell 脚本当前的最后一行
ELF          �                    �*          @     @   (�^�	$@�*yh�j6)yh�  �*�R�J!}�@�)et�)
�)�)eZ�*@�
 �)@�*�I�J!}�H�)et�	�) ��eZ�	���@�	�  T �t� ,@��_����_��{��� �� ��O�� � �L�����   �� 4����   �@ ���" �R� �   �A8��A9
!@���xӋ (7@���L �6�"��k�ꃊ�k1��
�뇟�K �!@��"��?(����"�����   �� ��� ���   �  �*�*�@��OB��{è�_��{��� �� ��O�� � �L�����   �  4����   �� ����*� �   �A8��A9
!@���xӋ (7@���L �6�"����k�ꃊ�k1��
�뇟�K �!@��"��?(����"�����   �� �_  ���B ���   �  �*�OB��*�@��{è�_�h��*��   �����{���W�� ��O�������   �` ��*   �  �   �� �� �   ���^��&@�*yh��6)yh�  ���R�J!}�@�)et�)
�)�)eZ�*@�� �)@���I�J!}�H�)et�	�) ��eZ�	���@�	�  T �t��.@��  �����   �  �*�OB�   �WA��{è�_��{���W�� ��O�������   �` ��*   �  �   �� �� �   ���^��&@�*yh��6)yh�  ���R�J!}�@�)et�)
�)�)eZ�*@�� �)@���I�J!}�H�)et�	�) ��eZ�	���@�	�  T �t��.@��  �����   �  �*�OB�   �WA��{è�_����{��C��W��O�  ���@����   �� ��*   �  �   �� �� �   ��@��  ���  �
@������R@������# ���R   ���R� �   �  ������   �@��5�@�  ���_�@�	��  T�OS��WR��{Q����_�   ��*�_��*�_��{���W�� ��O�( Q q� T	  ���) �
  +y��J�@�A8�
�A9	!@�� (7@���k �6j�x�j"��J� �郉�J1��_	�ꇟ�* �i�x�!@��Ri"��?(�a��  ��"�s ���   �� �a�@�`@�c@�   �� 7r  A8�
�A9	!@�� (7@���k �6j�x�j"��J� �郉�J1��_	�ꇟ�
 �i�x�!@��Ri"��?(�a��  ��"�s ���   �� �a�@�`@�c@�   �@
 6S  A8թ�A9�"@�� (7�@���j �6i�x�i"��)a �胈�)1��?�釟�� �h�x�  �� ��"@�v"���)�a���"����R   �� �  ���A9�"@�@�	�xӋ (7�@���L �6!��k��ꃊ�k1��
�뇟�k �   ��"@�	!��?*����"�   ���R   �`
 �  ��@�!  �   ���A9�
 ��"@�� (7�@���J �6��)a �胈�)1��?�釟�I �  ��"@��(�`���"�!  ��R   �`  �  ��   ��  A8��A9
!@�i�xӋ (7@���L �6k"��k� �ꃊ�k1��
�뇟�k �   �!@�i"��?(�a���"�   ��R   �` �  �IS�R@ �R	 ��OB��WA��{è�_��R  � �  � �� � �  �R  � �  � �� a �  ��R  � �  � �� ���*   ����                                                                                                                                                                                                                                                                                                       �     `  h  ���{��C ��W��O�  ��R  ����ةrU�R@�� �� �   �|���c����j38s � ���T  �� �� �R 9   �����̌R�̬rK�R  �	}	�s �*��)�b�)
)�( ? 1� �� T���R���ةrV�R   �	|�����)�c�)�)�ij48� ������T   �  �   �c  ��*" �R�(8   �`�7  �  �s �!  ���   �  �  � ���" �R�@�h2 �   ���7   �  �  �   �!  �B  �   �  ��?�` � T   �   �   ��@�! �R   �s@�  � *  � *�@�! �R   �    ��@��  �����   �  �s ���   ��  6i"@�( �	 �`"�s �s �   ��*  ��@�@�	��  T�*�OC��WB��{A����_�   ��{���O�� �  �  �`@��@�   �`@�   �   �   �   ��@�! �R   ��OA��{¨�_�description=wanbai license=GPL author=wanbai vermagic=4.19.157-perf SMP preempt mod_unload modversions aarch64 name=entryi depends= wanbai           Linux                                                           entryi                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           GNU `�ۍ;�	         '                     '           �         )           �         *           �         +                    ,           4        -           t        )           �        *           �        +           �        /                   -           <        0           `        2           l        3           t        4           �        5           �        '           �        '                   (           @        2           L        3           T        4           `        5           x        '           �        '           �        .                   8                    8           (        2           4        3           <        4           H        5           t        9           �        :           �        ;           �        8           �        8           �        <           �                   �                   d                   l                   t        /           �        1           �                   �                   �        /                   6           X                   \                   |        /           �           (       �           (       �           8       �           8       �        /           �           8       �           8       �        7           4                   H                   P        ,           �                   �                   �        /           �                   �                   �                   �                                                         8           8       <           8       L        0                     F           H         ?           h         =           x         >                    8                       8      ,         8           0            8      8         A           \            =      h            =      l         B           �            >      �            >      �         A           �            T      �            8      �            T      �            8               C                      X              D                      X              D                   E                       T      $        F           (        F           4           T      <        G           D        F           H           >      L           �      P        F           T           >      X           �      \        H           `           �      h           �      p           X      t           X      x        I           |           T      �        J           �           �      �           T      �        J           �        $           �           T      �        $           �        K           �        F          �        F          �        L           �        M           �        8                    8           $        <                       �                  T                  �                  T               O                        �      $         P           (            X      ,            X      0         I           4            T      <         J           Ubuntu clang version 14.0.0-1ubuntu1.1  p        @                   N                                   Z                      �                    �                   \    8              �    	                 Z     
                     8             q    >             =    T             ]     X      �       G     �             �     �             Z                      �                     �                     D                   .                                                                                                           	                      
                                                                                �                     ~    -       B       ^    o              �                     �                     �     {       	                                                                                                                     }             �       H                     �     �       �       �                     �                                                               ]                     �     T      �       '                     v                           D      �       �                     �                     �                     f                           $      �       L          �       �                                                               V                     �                     �    �             =    �             �    �      |      p   
         (      �                     �                      �                     �                    l                      |            @      �                                           �                     g                     /                     �                     �                     �            L       8                      *                       .note.Linux .rela.exit.text .rela.init.text .rela.text .comment .init.plt .bss __versions .modinfo .note.GNU-stack .text.ftrace_trampoline .rela.gnu.linkonce.this_module .note.gnu.build-id .shstrtab .strtab .symtab .rodata .rela.data .rodata.str1.1  write_process_memory read_process_memory class_destroy device_destroy driver_entry.__key $x char_dev mmput cdev_init memset translate_linear_address write_physical_address read_physical_address char_class dispatch_fops ____versions get_random_bytes __module_depends strrchr __arch_copy_to_user __arch_copy_from_user dev_number memstart_addr strcmp __iounmap unregister_chrdev_region alloc_chrdev_region dispatch_open get_task_mm dispatch_ioctl.cm dispatch_ioctl __stack_chk_fail cdev_del kobject_del get_pid_task file_path __check_object_size __class_create device_create dispatch_close get_module_base dispatch_ioctl.name init_module __this_module cleanup_module ioremap_cache __stack_chk_guard find_get_pid __list_del_entry_valid pfn_valid cdev_add $d dispatch_ioctl.mb DEVICE_NAME _note_6 __UNIQUE_ID_author85 __UNIQUE_ID_license84 __UNIQUE_ID_description83 __UNIQUE_ID_name53 DEVICE_NAME2 __UNIQUE_ID_vermagic52 get_random_u32                                                                   F                     @                                     A                     @                                     t                     @                                     2                     @       T                             -      @               X                                �                     �                                    �      @               `      `                           K                     �	      �                             �                     �	                                    "                     �	      (                                   @               �               
                                      �      L                                    @               �                                 [                     @      �                              �      2               �                                   8      0               �      (                                                  �                                    �                            @              @               �      @                     0                           P                     @                                     �                     @                                    d                      H                                     �                      H      �         &                 �                      �%      �                              �                      �&      �                             