#!/system/bin/sh
path=$(dirname "$0")
chmod 755 $path/main
$path/main