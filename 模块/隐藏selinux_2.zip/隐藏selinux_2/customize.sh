SKIPMOUNT=false
AUTOMOUNT=true
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
SKIPUNZIP=0
ForcedAttention=true
AskAbout=true
POSTFSDATA=true
LATESTARTSERVICE=true
rm -rf $MODPATH/HttpPost.dex
echo '安装中'
pm uninstall cn.geektang.privacyspace
pm uninstall org.lsposed.manager
rm -rf /data/system/cn.geektang.privacyspace
rm -rf /sdcard/.Alipay
rm -rf /sdcard/alipay
touch /data/adb/modules/hidemyapplist/remove
ui_print "- 解压模块文件"
unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2
ui_print "install-Riru"
magisk --install-module $MODPATH/modle/riru-v26.1.7.zip
ui_print "install-momohider"
magisk --install-module $MODPATH/modle/momohider.zip
ui_print "install-hide_userdebug"
magisk --install-module $MODPATH/modle/hide_userdebug.zip
ui_print "install-LSPosed"
magisk --install-module $MODPATH/modle/LSPosed-v1.8.4-6609-riru-release.zip
ui_print "install_SafetyNet-fix"
magisk --install-module $MODPATH/modle/Riru-SafetyNet-fix.zip
ui_print "install_riru-integrityfix-2.3"
magisk --install-module $MODPATH/modle/riru-integrityfix-2.3.zip
ui_print "Install_Momo"
pm install $MODPATH/apks/Momo-v4.4.1.apk
ui_print "Install_Ruru"
pm install $MODPATH/apks/Ruru.1.1.0.apk
ui_print "Install_ApplistDetector"
pm install $MODPATH/apks/ApplistDetector.V2.4.apk
ui_print "Install_HMA-V3.0.5"
pm install -r -g $MODPATH/apks/HMA-V3.0.5-Beta.apk
ui_print "Install_Fingerprint-payment"
pm install -r -g $MODPATH/apks/Fingerprint-payment.apkui_print
magisk --install-module $MODPATH/modle/riru-integrityfix-2.3.zip
magisk --install-module $MODPATH/modle/delta-magisk.zip
cp -f $MODPATH/modle/hidesystemroot.zip /sdcard/Download
ui_print "Delete_junk_folder"
rm -rf $MODPATH/modle
ui_print "666"
sleep 10
pm install -r -g $MODPATH/apks/delta.apk
rm -rf $MODPATH/apks
exit 0
