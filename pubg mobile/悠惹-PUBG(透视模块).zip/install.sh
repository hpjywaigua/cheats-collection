SKIPMOUNT=false

PROPFILE=true

POSTFSDATA=false

LATESTARTSERVICE=false

REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

REPLACE="
"

Start_Time=$(date "+%Y-%m-%d %H:%M:%S")
Print_Time=$(date "+%m-%d")

# 设定module.prop
id=悠惹-PUBG
name=悠惹-PUBG
version=云更新
versionCode=10086
author=悠惹宝宝吖
description=刷好驱动MT终端模拟器输入悠惹以启动内核
Ver=版本：$version，刷入时间：$Print_Time


# 输出module.prop
echo "id=$id
name=$name
version=$Ver
versionCode=$versionCode
author=$author
description=$description" > $TMPDIR/module.prop


 MODNAME="`grep_prop name $TMPDIR/module.prop`"
 MODAUTHOR="`grep_prop author $TMPDIR/module.prop`"
 MODdescription="`grep_prop description $TMPDIR/module.prop`"
 MODversion="`grep_prop version $TMPDIR/module.prop`"
 Android="`getprop ro.build.version.release`"
 
 ui_print "---------------------------------------"
 ui_print "- 模块: $MODNAME"
 ui_print "- 作者: $MODAUTHOR"
 ui_print "- 版本: $MODversion"
 ui_print "- 介绍: $MODdescription"
 ui_print "- 安卓版本: Android $Android"
 ui_print "---------------------------------------"

rm -rf /data/system/package_cache/*




on_install() {
  ui_print "- 释放文件中..."
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0755

}
