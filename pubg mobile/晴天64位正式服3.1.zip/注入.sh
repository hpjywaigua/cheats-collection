Color_Off='\e[0m'       # Text Reset
BIPurple='\e[1;95m'     # Purple
BIRed='\e[1;33m'       # Red

tt="晴天
"

#next line
PS3=("请输入以上序号 
$tt")
echo -e "${BIRed}"
options=("国际服" "台湾服" "日韩服" "越南服" "退出")
select opt in "${options[@]}"
do
    case $opt in
        "国际服")
clear
path=`pm path com.tencent.ig | sed -E  's/(.*):(.*)/\2/'| sed -E 's/(.*)base.apk/\1/'`"lib/arm64/"
cp -f `pwd`"/inject.so" $path"inject.so"
chmod 777 $path"inject.so"
cp -f `pwd`"/libQT.so" $path"libQT.so"
chmod 777 $path"libQT.so"

am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity
sleep 1

$path"inject.so" --pname com.tencent.ig --libpath $path"libQT.so"
            ;;
        "日韩服")
clear
path=`pm path com.pubg.krmobile | sed -E  's/(.*):(.*)/\2/'| sed -E 's/(.*)base.apk/\1/'`"lib/arm64/"
cp -f `pwd`"/inject.so" $path"inject.so"
chmod 777 $path"inject.so"
cp -f `pwd`"/libQT.so" $path"libQT.so"
chmod 777 $path"libQT.so"

am start -n com.pubg.krmobile/com.epicgames.ue4.SplashActivity
sleep 1

$path"inject.so" --pname com.pubg.krmobile --libpath $path"libQT.so"
            ;;
        "台湾服")
clear
path=`pm path com.rekoo.pubgm | sed -E  's/(.*):(.*)/\2/'| sed -E 's/(.*)base.apk/\1/'`"lib/arm64/"
cp -f `pwd`"/inject.so" $path"inject.so"
chmod 777 $path"inject.so"
cp -f `pwd`"/libQT.so" $path"libQT.so"
chmod 777 $path"libQT.so"

am start -n com.rekoo.pubgm/com.epicgames.ue4.SplashActivity
sleep 1

$path"inject.so" --pname com.rekoo.pubgm --libpath $path"libQT.so"
            ;;
        "越南服")
clear
path=`pm path com.vng.pubgmobile | sed -E  's/(.*):(.*)/\2/'| sed -E 's/(.*)base.apk/\1/'`"lib/arm64/"
cp -f `pwd`"/inject.so" $path"inject.so"
chmod 777 $path"inject.so"
cp -f `pwd`"/libQT.so" $path"libQT.so"
chmod 777 $path"libQT.so"

am start -n com.vng.pubgmobile/com.epicgames.ue4.SplashActivity
sleep 1

$path"inject.so" --pname com.vng.pubgmobile --libpath $path"libQT.so"
            ;;
 
        "退出")
            break
            ;;
        *) echo "选项无效 $REPLY";;
    esac
done