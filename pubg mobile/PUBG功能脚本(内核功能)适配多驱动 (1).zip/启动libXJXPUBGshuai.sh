cp libXJXPUBGshuai.so /data/local/tmp/libXJXPUBGshuai.so
chmod 777 /data/local/tmp/libXJXPUBGshuai.so
/data/local/tmp/libXJXPUBGshuai.so