#!/bin/bash
password="Czenb6"
while true; do
echo -e "\n\n\033[41mTG公益频道:@Czenb6\033[0m\n"
echo -e "\033[41m此清理会删除Download下载无用文件，请提前备份！\033[0m\n"
echo -e "\033[41m请仔细阅读使用说明，不看别叫！！\033[0m\n"
sleep 2
echo "\n必须在上号之前执行！！！\n"
    echo -e "\n\033[41m密码:Czenb6\033[0m"
    echo -n "\n\n请输入密码，注意区分大小写字母： "
    read -r input_password
    if [ "$input_password" = "$password" ]; then
        echo -e "\033[41m密码正确，原神，启动！\033[0m"
        sleep 3

echo -e "\n\n\033[41m正在初始化！\033[0m"
echo -e "\033[41m电报频道:Czenb6\033[0m"
Color_Off='\e[0m'       # Text Reset
BIPurple='\e[1;95m'     # Purple
BIRed='\e[1;33m'       # Red

tt="频道@Czenb6.
"

#next line
PS3=("请输入以上要重置游客游戏的序号 
$tt ")
echo -e "${BIRed}"
options=("国际服" "日韩服" "台湾服" "越南服" "退出")
select opt in "${options[@]}"
do
    case $opt in
        "国际服")
clear
echo -e "${BIPurple}"
sleep 0.5
echo
echo "正在准备清理..."
echo -ne '                   \033[1;37m  □□□□□□□□□□0% \r'
sleep 0.1
echo -ne '                   \033[1;31m  ■□□□□□□□□□10% \r'
sleep 0.1
echo -ne '                   \033[1;31m  ■■□□□□□□□□20% \r'
sleep 0.1
echo -ne '                   \033[1;33m  ■■■□□□□□□□30% \r'
sleep 0.1
echo -ne '                   \033[1;33m  ■■■■□□□□□□40% \r'
sleep 0.1
echo -ne '                   \033[1;33m  ■■■■■□□□□□50% \r'
sleep 0.1
echo -ne '                   \033[1;36m  ■■■■■■□□□□60% \r'
sleep 0.1
echo -ne '                   \033[1;36m  ■■■■■■■□□□70% \r'
sleep 0.1
echo -ne '                   \033[1;36m  ■■■■■■■■□□80% \r'
sleep 0.1
echo -ne '                   \033[1;32m  ■■■■■■■■■□90% \r'
sleep 0.1
echo -ne '                   \033[1;32m  ■■■■■■■■■■100% \r'
sleep 0.1
sleep 1
clear

kill com.tencent.ig
clear
am force-stop com.tencent.ig
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game /storage/emulated/0/Android/data/com.tencent.ig/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.ig/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.ig/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game

mv /storage/emulated/0/Android/data/com.tencent.ig/files /storage/emulated/0/Android/data/com.tencent.ig/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/*
mv /storage/emulated/0/Android/data/com.tencent.ig/.files /storage/emulated/0/Android/data/com.tencent.ig/files

#mv /data/data/com.tencent.ig/lib /data/data/com.tencent.ig/.lib
#rm -rf /data/data/com.tencent.ig/*
#mv /data/data/com.tencent.ig/.lib /data/data/com.tencent.ig/lib

mv /storage/emulated/0/Android/data/com.tencent.ig /storage/emulated/0/Android/data/com.tencent.ig1
pm clear com.tencent.ig
mv /storage/emulated/0/Android/data/com.tencent.ig1 /storage/emulated/0/Android/data/com.tencent.ig

echo
echo 马上清除全部封号信息√
echo
echo 请修改设备ID
echo
echo 否则游戏又会在本地生成该设备的封禁信息日志

echo 开始运行第二步
am force-stop com.tencent.ig
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game /storage/emulated/0/Android/data/com.tencent.ig/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.ig/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.ig/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game

mv /storage/emulated/0/Android/data/com.tencent.ig/files /storage/emulated/0/Android/data/com.tencent.ig/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/*
mv /storage/emulated/0/Android/data/com.tencent.ig/.files /storage/emulated/0/Android/data/com.tencent.ig/files

#mv /data/data/com.tencent.ig/lib /data/data/com.tencent.ig/.lib
#rm -rf /data/data/com.tencent.ig/*
#mv /data/data/com.tencent.ig/.lib /data/data/com.tencent.ig/lib

mv /storage/emulated/0/Android/data/com.tencent.ig /storage/emulated/0/Android/data/com.tencent.ig1
pm clear com.tencent.ig
mv /storage/emulated/0/Android/data/com.tencent.ig1 /storage/emulated/0/Android/data/com.tencent.ig
echo 成功！开始更换ID 
echo 成功！开始更换ID 

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.tencent.ig
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml

echo 开始第三步

echo 开始运行清理残留
am force-stop com.tencent.ig
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game /storage/emulated/0/Android/data/com.tencent.ig/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.ig/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.ig/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game

mv /storage/emulated/0/Android/data/com.tencent.ig/files /storage/emulated/0/Android/data/com.tencent.ig/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/*
mv /storage/emulated/0/Android/data/com.tencent.ig/.files /storage/emulated/0/Android/data/com.tencent.ig/files

#mv /data/data/com.tencent.ig/lib /data/data/com.tencent.ig/.lib
#rm -rf /data/data/com.tencent.ig/*
#mv /data/data/com.tencent.ig/.lib /data/data/com.tencent.ig/lib

mv /storage/emulated/0/Android/data/com.tencent.ig /storage/emulated/0/Android/data/com.tencent.ig1
pm clear com.tencent.ig
mv /storage/emulated/0/Android/data/com.tencent.ig1 /storage/emulated/0/Android/data/com.tencent.ig
echo 成功 更改ID

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.tencent.ig
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml

echo 正在执行第4步
system_path=/private/var/mobile/Containers/Data/Application
app_path=""
for file in $system_path/*; do
    if [ -d "$file/Documents/ShadowTrackerExtra" ];then
		app_path="$file"
	fi
done

echo -e "找到pung根目录: $app_path"

# 删除 /Documents/tss_tmp
delete_path=$app_path/Documents/tss_tmp
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tdm.db
delete_path=$app_path/Documents/tdm.db
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tss_app_915c.dat
delete_path=$app_path/Documents/tss_app_915c.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tss_cs_stat2.dat
delete_path=$app_path/Documents/tss_cs_stat2.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
delete_path=$app_path/Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tss.i.m.dat
delete_path=$app_path/Documents/tss.i.m.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tersafe.update
delete_path=$app_path/Documents/tersafe.update
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/ShadowTrackerExtra/Saved/Logs
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Logs
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/ShadowTrackerExtra/Saved/Config
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Config
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/Caches
delete_path=$app_path/Library/Caches
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/'Saved Application State'
delete_path=$app_path/Library/'Saved Application State'
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/MidasLog
delete_path=$app_path/Library/MidasLog
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/WebKit
delete_path=$app_path/Library/WebKit
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/Cookies
delete_path=$app_path/Library/Cookies
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/'Application Support'
delete_path=$app_path/Library/'Application Support'
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/APWsjGameConfInfo.plist
delete_path=$app_path/Library/APWsjGameConfInfo.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /private/var/gg_address
delete_path=/private/var/gg_address
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/sp_default.plist
delete_path=$app_path/Documents/sp_default.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/'ts.records'
delete_path=$app_path/Library/'ts.records'
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/ts
delete_path=$app_path/Library/ts
rm -rf $delete_path
echo "删除 $delete_path 完成"

echo 正在清理...
am force-stop com.tencent.ig
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game /storage/emulated/0/Android/data/com.tencent.ig/files/.UE4Game
mv /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.ig/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/*
mv /storage/emulated/0/Android/data/com.tencent.ig/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.tencent.ig/files/.UE4Game /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game

mv /storage/emulated/0/Android/data/com.tencent.ig/files /storage/emulated/0/Android/data/com.tencent.ig/.files
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/*
mv /storage/emulated/0/Android/data/com.tencent.ig/.files /storage/emulated/0/Android/data/com.tencent.ig/files


mv /storage/emulated/0/Android/data/com.tencent.ig /storage/emulated/0/Android/data/com.tencent.ig1
pm clear com.tencent.ig
mv /storage/emulated/0/Android/data/com.tencent.ig1 /storage/emulated/0/Android/data/com.tencent.ig

echo 正在执行第五步

echo 0 > /proc/sys/net/nf_conntrack_max
echo 清理成功
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 清理成功
echo 0 > /proc/sys/kernel/max_lock_depth
echo 清理成功

rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/midas/log/com.tencent.ig/

iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z

chmod 0 /data/data/com.tencent.ig/files/ano_tmp
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.ig/databases
chmod 000 //data/data/com.tencent.ig/files/*tmp*
chmod 000 /data/data/com.tencent.ig/files/ano_tmp
PKG=com.tencent.ig
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml


echo -n "时间："
date "+%Y年%H时%M分%S秒"
echo -n "设备："
getprop ro.product.brand
echo -n "设备类型："
getprop ro.product.model

echo 修改完成，需重启系统后生效 √

echo -e "\033[41m清理成功 \033[0m"

echo 正在执行第六步
echo 0 > /proc/sys/net/nf_conntrack_max
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 0 > /proc/sys/kernel/max_lock_depth

rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.tencent.ig/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/midas/log/com.tencent.ig/

chmod 0 /data/data/com.tencent.ig/files/ano_tmp
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/comm.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.tencent.ig/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.tencent.ig/databases
chmod 000 //data/data/com.tencent.ig/files/*tmp*
chmod 000 /data/data/com.tencent.ig/files/ano_tmp
echo -e "\033[41m--- 清理文件成功---\033[0m"
sleep 3s


echo -e "\033[41m---正在自动为你检查一遍是否清理成功---\033[0m"
echo -e "\033[41m---请稍等马上检查完成---\033[0m"
sleep 5s

PKG=com.tencent.ig
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml

echo -e "\033[41m---清理文件成功 退出即可---\033[0m"
echo -e "\033[41m---请更改ID重启手机在上号---\033[0m"
echo -e "\033[41m---公益频道@Czenb6---\033[0m"

 
            ;;
        "日韩服")
clear
echo -e "${BIPurple}"
sleep 0.5
echo
echo "正在准备清理..."
echo -ne '                   \033[1;37m  □□□□□□□□□□0% \r'
sleep 0.1
echo -ne '                   \033[1;31m  ■□□□□□□□□□10% \r'
sleep 0.1
echo -ne '                   \033[1;31m  ■■□□□□□□□□20% \r'
sleep 0.1
echo -ne '                   \033[1;33m  ■■■□□□□□□□30% \r'
sleep 0.1
echo -ne '                   \033[1;33m  ■■■■□□□□□□40% \r'
sleep 0.1
echo -ne '                   \033[1;33m  ■■■■■□□□□□50% \r'
sleep 0.1
echo -ne '                   \033[1;36m  ■■■■■■□□□□60% \r'
sleep 0.1
echo -ne '                   \033[1;36m  ■■■■■■■□□□70% \r'
sleep 0.1
echo -ne '                   \033[1;36m  ■■■■■■■■□□80% \r'
sleep 0.1
echo -ne '                   \033[1;32m  ■■■■■■■■■□90% \r'
sleep 0.1
echo -ne '                   \033[1;32m  ■■■■■■■■■■100% \r'
sleep 0.1
sleep 1
clear
kill com.pubg.krmobile
clear
am force-stop com.pubg.krmobile
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game /storage/emulated/0/Android/data/com.pubg.krmobile/files/.UE4Game
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.pubg.krmobile/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/.UE4Game /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files /storage/emulated/0/Android/data/com.pubg.krmobile/.files
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/.files /storage/emulated/0/Android/data/com.pubg.krmobile/files

#mv /data/data/com.pubg.krmobile/lib /data/data/com.pubg.krmobile/.lib
#rm -rf /data/data/com.pubg.krmobile/*
#mv /data/data/com.pubg.krmobile/.lib /data/data/com.pubg.krmobile/lib

mv /storage/emulated/0/Android/data/com.pubg.krmobile /storage/emulated/0/Android/data/com.pubg.krmobile1
pm clear com.pubg.krmobile
mv /storage/emulated/0/Android/data/com.pubg.krmobile1 /storage/emulated/0/Android/data/com.pubg.krmobile

echo
echo 马上清除全部封号信息√
echo
echo 请修改设备ID
echo
echo 否则游戏又会在本地生成该设备的封禁信息日志

echo 开始运行第二步
am force-stop com.pubg.krmobile
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game /storage/emulated/0/Android/data/com.pubg.krmobile/files/.UE4Game
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.pubg.krmobile/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/.UE4Game /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files /storage/emulated/0/Android/data/com.pubg.krmobile/.files
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/.files /storage/emulated/0/Android/data/com.pubg.krmobile/files

#mv /data/data/com.pubg.krmobile/lib /data/data/com.pubg.krmobile/.lib
#rm -rf /data/data/com.pubg.krmobile/*
#mv /data/data/com.pubg.krmobile/.lib /data/data/com.pubg.krmobile/lib

mv /storage/emulated/0/Android/data/com.pubg.krmobile /storage/emulated/0/Android/data/com.pubg.krmobile1
pm clear com.pubg.krmobile
mv /storage/emulated/0/Android/data/com.pubg.krmobile1 /storage/emulated/0/Android/data/com.pubg.krmobile
echo 成功！开始更换ID 
echo 成功！开始更换ID 

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.pubg.krmobile
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml

echo 开始第三步

echo 开始运行清理残留
am force-stop com.pubg.krmobile
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game /storage/emulated/0/Android/data/com.pubg.krmobile/files/.UE4Game
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.pubg.krmobile/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/.UE4Game /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files /storage/emulated/0/Android/data/com.pubg.krmobile/.files
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/.files /storage/emulated/0/Android/data/com.pubg.krmobile/files

#mv /data/data/com.pubg.krmobile/lib /data/data/com.pubg.krmobile/.lib
#rm -rf /data/data/com.pubg.krmobile/*
#mv /data/data/com.pubg.krmobile/.lib /data/data/com.pubg.krmobile/lib

mv /storage/emulated/0/Android/data/com.pubg.krmobile /storage/emulated/0/Android/data/com.pubg.krmobile1
pm clear com.pubg.krmobile
mv /storage/emulated/0/Android/data/com.pubg.krmobile1 /storage/emulated/0/Android/data/com.pubg.krmobile
echo 成功 更改ID

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.pubg.krmobile
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml

echo 正在执行第4步
system_path=/private/var/mobile/Containers/Data/Application
app_path=""
for file in $system_path/*; do
    if [ -d "$file/Documents/ShadowTrackerExtra" ];then
		app_path="$file"
	fi
done

echo -e "找到pung根目录: $app_path"

# 删除 /Documents/tss_tmp
delete_path=$app_path/Documents/tss_tmp
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tdm.db
delete_path=$app_path/Documents/tdm.db
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tss_app_915c.dat
delete_path=$app_path/Documents/tss_app_915c.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tss_cs_stat2.dat
delete_path=$app_path/Documents/tss_cs_stat2.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
delete_path=$app_path/Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tss.i.m.dat
delete_path=$app_path/Documents/tss.i.m.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tersafe.update
delete_path=$app_path/Documents/tersafe.update
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/ShadowTrackerExtra/Saved/Logs
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Logs
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/ShadowTrackerExtra/Saved/Config
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Config
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/Caches
delete_path=$app_path/Library/Caches
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/'Saved Application State'
delete_path=$app_path/Library/'Saved Application State'
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/MidasLog
delete_path=$app_path/Library/MidasLog
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/WebKit
delete_path=$app_path/Library/WebKit
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/Cookies
delete_path=$app_path/Library/Cookies
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/'Application Support'
delete_path=$app_path/Library/'Application Support'
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/APWsjGameConfInfo.plist
delete_path=$app_path/Library/APWsjGameConfInfo.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /private/var/gg_address
delete_path=/private/var/gg_address
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/sp_default.plist
delete_path=$app_path/Documents/sp_default.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/'ts.records'
delete_path=$app_path/Library/'ts.records'
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/ts
delete_path=$app_path/Library/ts
rm -rf $delete_path
echo "删除 $delete_path 完成"

echo 正在清理...
am force-stop com.pubg.krmobile
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game /storage/emulated/0/Android/data/com.pubg.krmobile/files/.UE4Game
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.pubg.krmobile/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.pubg.krmobile/files/.UE4Game /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game

mv /storage/emulated/0/Android/data/com.pubg.krmobile/files /storage/emulated/0/Android/data/com.pubg.krmobile/.files
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/*
mv /storage/emulated/0/Android/data/com.pubg.krmobile/.files /storage/emulated/0/Android/data/com.pubg.krmobile/files


mv /storage/emulated/0/Android/data/com.pubg.krmobile /storage/emulated/0/Android/data/com.pubg.krmobile1
pm clear com.pubg.krmobile
mv /storage/emulated/0/Android/data/com.pubg.krmobile1 /storage/emulated/0/Android/data/com.pubg.krmobile

echo 正在执行第五步

echo 0 > /proc/sys/net/nf_conntrack_max
echo 清理成功
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 清理成功
echo 0 > /proc/sys/kernel/max_lock_depth
echo 清理成功

rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/midas/log/com.pubg.krmobile/

iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z

chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/comm.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.pubg.krmobile/databases
chmod 000 //data/data/com.pubg.krmobile/files/*tmp*
chmod 000 /data/data/com.pubg.krmobile/files/ano_tmp
PKG=com.pubg.krmobile
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml


echo -n "时间："
date "+%Y年%H时%M分%S秒"
echo -n "设备："
getprop ro.product.brand
echo -n "设备类型："
getprop ro.product.model

echo 修改完成，需重启系统后生效 √

echo -e "\033[41m清理成功 \033[0m"

echo 正在执行第六步
echo 0 > /proc/sys/net/nf_conntrack_max
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 0 > /proc/sys/kernel/max_lock_depth

rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.pubg.krmobile/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.pubg.krmobile/files/midas/log/com.pubg.krmobile/

chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/comm.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.pubg.krmobile/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.pubg.krmobile/databases
chmod 000 //data/data/com.pubg.krmobile/files/*tmp*
chmod 000 /data/data/com.pubg.krmobile/files/ano_tmp
echo -e "\033[41m--- 清理文件成功---\033[0m"
sleep 3s


echo -e "\033[41m---正在自动为你检查一遍是否清理成功---\033[0m"
echo -e "\033[41m---请稍等马上检查完成---\033[0m"
sleep 5s

PKG=com.pubg.krmobile
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml

echo -e "\033[41m---清理文件成功 退出即可---\033[0m"
echo -e "\033[41m---请更改ID重启手机在上号---\033[0m"
echo -e "\033[41m---公益频道@Czenb6---\033[0m"

 
            ;;
        "台湾服")
clear
echo -e "${BIPurple}"
sleep 0.5
echo
echo "正在准备清理..."
echo -ne '                   \033[1;37m  □□□□□□□□□□0% \r'
sleep 0.1
echo -ne '                   \033[1;31m  ■□□□□□□□□□10% \r'
sleep 0.1
echo -ne '                   \033[1;31m  ■■□□□□□□□□20% \r'
sleep 0.1
echo -ne '                   \033[1;33m  ■■■□□□□□□□30% \r'
sleep 0.1
echo -ne '                   \033[1;33m  ■■■■□□□□□□40% \r'
sleep 0.1
echo -ne '                   \033[1;33m  ■■■■■□□□□□50% \r'
sleep 0.1
echo -ne '                   \033[1;36m  ■■■■■■□□□□60% \r'
sleep 0.1
echo -ne '                   \033[1;36m  ■■■■■■■□□□70% \r'
sleep 0.1
echo -ne '                   \033[1;36m  ■■■■■■■■□□80% \r'
sleep 0.1
echo -ne '                   \033[1;32m  ■■■■■■■■■□90% \r'
sleep 0.1
echo -ne '                   \033[1;32m  ■■■■■■■■■■100% \r'
sleep 0.1
sleep 1
clear
kill com.rekoo.pubgm
clear
am force-stop com.rekoo.pubgm
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.UE4Game
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.rekoo.pubgm/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.UE4Game /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files /storage/emulated/0/Android/data/com.rekoo.pubgm/.files
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/.files /storage/emulated/0/Android/data/com.rekoo.pubgm/files

#mv /data/data/com.rekoo.pubgm/lib /data/data/com.rekoo.pubgm/.lib
#rm -rf /data/data/com.rekoo.pubgm/*
#mv /data/data/com.rekoo.pubgm/.lib /data/data/com.rekoo.pubgm/lib

mv /storage/emulated/0/Android/data/com.rekoo.pubgm /storage/emulated/0/Android/data/com.rekoo.pubgm1
pm clear com.rekoo.pubgm
mv /storage/emulated/0/Android/data/com.rekoo.pubgm1 /storage/emulated/0/Android/data/com.rekoo.pubgm

echo
echo 马上清除全部封号信息√
echo
echo 请修改设备ID
echo
echo 否则游戏又会在本地生成该设备的封禁信息日志

echo 开始运行第二步
am force-stop com.rekoo.pubgm
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.UE4Game
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.rekoo.pubgm/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.UE4Game /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files /storage/emulated/0/Android/data/com.rekoo.pubgm/.files
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/.files /storage/emulated/0/Android/data/com.rekoo.pubgm/files

#mv /data/data/com.rekoo.pubgm/lib /data/data/com.rekoo.pubgm/.lib
#rm -rf /data/data/com.rekoo.pubgm/*
#mv /data/data/com.rekoo.pubgm/.lib /data/data/com.rekoo.pubgm/lib

mv /storage/emulated/0/Android/data/com.rekoo.pubgm /storage/emulated/0/Android/data/com.rekoo.pubgm1
pm clear com.rekoo.pubgm
mv /storage/emulated/0/Android/data/com.rekoo.pubgm1 /storage/emulated/0/Android/data/com.rekoo.pubgm
echo 成功！开始更换ID 
echo 成功！开始更换ID 

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.rekoo.pubgm
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml

echo 开始第三步

echo 开始运行清理残留
am force-stop com.rekoo.pubgm
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.UE4Game
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.rekoo.pubgm/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.UE4Game /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files /storage/emulated/0/Android/data/com.rekoo.pubgm/.files
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/.files /storage/emulated/0/Android/data/com.rekoo.pubgm/files

#mv /data/data/com.rekoo.pubgm/lib /data/data/com.rekoo.pubgm/.lib
#rm -rf /data/data/com.rekoo.pubgm/*
#mv /data/data/com.rekoo.pubgm/.lib /data/data/com.rekoo.pubgm/lib

mv /storage/emulated/0/Android/data/com.rekoo.pubgm /storage/emulated/0/Android/data/com.rekoo.pubgm1
pm clear com.rekoo.pubgm
mv /storage/emulated/0/Android/data/com.rekoo.pubgm1 /storage/emulated/0/Android/data/com.rekoo.pubgm
echo 成功 更改ID

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.rekoo.pubgm
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml

echo 正在执行第4步
system_path=/private/var/mobile/Containers/Data/Application
app_path=""
for file in $system_path/*; do
    if [ -d "$file/Documents/ShadowTrackerExtra" ];then
		app_path="$file"
	fi
done

echo -e "找到pung根目录: $app_path"

# 删除 /Documents/tss_tmp
delete_path=$app_path/Documents/tss_tmp
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tdm.db
delete_path=$app_path/Documents/tdm.db
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tss_app_915c.dat
delete_path=$app_path/Documents/tss_app_915c.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tss_cs_stat2.dat
delete_path=$app_path/Documents/tss_cs_stat2.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
delete_path=$app_path/Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tss.i.m.dat
delete_path=$app_path/Documents/tss.i.m.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tersafe.update
delete_path=$app_path/Documents/tersafe.update
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/ShadowTrackerExtra/Saved/Logs
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Logs
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/ShadowTrackerExtra/Saved/Config
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Config
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/Caches
delete_path=$app_path/Library/Caches
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/'Saved Application State'
delete_path=$app_path/Library/'Saved Application State'
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/MidasLog
delete_path=$app_path/Library/MidasLog
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/WebKit
delete_path=$app_path/Library/WebKit
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/Cookies
delete_path=$app_path/Library/Cookies
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/'Application Support'
delete_path=$app_path/Library/'Application Support'
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/APWsjGameConfInfo.plist
delete_path=$app_path/Library/APWsjGameConfInfo.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /private/var/gg_address
delete_path=/private/var/gg_address
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/sp_default.plist
delete_path=$app_path/Documents/sp_default.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/'ts.records'
delete_path=$app_path/Library/'ts.records'
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/ts
delete_path=$app_path/Library/ts
rm -rf $delete_path
echo "删除 $delete_path 完成"

echo 正在清理...
am force-stop com.rekoo.pubgm
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.UE4Game
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.rekoo.pubgm/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files/.UE4Game /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game

mv /storage/emulated/0/Android/data/com.rekoo.pubgm/files /storage/emulated/0/Android/data/com.rekoo.pubgm/.files
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/*
mv /storage/emulated/0/Android/data/com.rekoo.pubgm/.files /storage/emulated/0/Android/data/com.rekoo.pubgm/files


mv /storage/emulated/0/Android/data/com.rekoo.pubgm /storage/emulated/0/Android/data/com.rekoo.pubgm1
pm clear com.rekoo.pubgm
mv /storage/emulated/0/Android/data/com.rekoo.pubgm1 /storage/emulated/0/Android/data/com.rekoo.pubgm

echo 正在执行第五步

echo 0 > /proc/sys/net/nf_conntrack_max
echo 清理成功
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 清理成功
echo 0 > /proc/sys/kernel/max_lock_depth
echo 清理成功

rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/midas/log/com.rekoo.pubgm/

iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z

chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/comm.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.rekoo.pubgm/databases
chmod 000 //data/data/com.rekoo.pubgm/files/*tmp*
chmod 000 /data/data/com.rekoo.pubgm/files/ano_tmp
PKG=com.rekoo.pubgm
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml


echo -n "时间："
date "+%Y年%H时%M分%S秒"
echo -n "设备："
getprop ro.product.brand
echo -n "设备类型："
getprop ro.product.model

echo 修改完成，需重启系统后生效 √

echo -e "\033[41m清理成功 \033[0m"

echo 正在执行第六步
echo 0 > /proc/sys/net/nf_conntrack_max
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 0 > /proc/sys/kernel/max_lock_depth

rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.rekoo.pubgm/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.rekoo.pubgm/files/midas/log/com.rekoo.pubgm/

chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/comm.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.rekoo.pubgm/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.rekoo.pubgm/databases
chmod 000 //data/data/com.rekoo.pubgm/files/*tmp*
chmod 000 /data/data/com.rekoo.pubgm/files/ano_tmp
echo -e "\033[41m--- 清理文件成功---\033[0m"
sleep 3s


echo -e "\033[41m---正在自动为你检查一遍是否清理成功---\033[0m"
echo -e "\033[41m---请稍等马上检查完成---\033[0m"
sleep 5s

PKG=com.rekoo.pubgm
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml

echo -e "\033[41m---清理文件成功 退出即可---\033[0m"
echo -e "\033[41m---请更改ID重启手机在上号---\033[0m"
echo -e "\033[41m---公益频道@Czenb6---\033[0m"

            ;;
        "越南服")
clear
echo -e "${BIPurple}"
sleep 0.5
echo
echo "正在准备清理..."
echo -ne '                   \033[1;37m  □□□□□□□□□□0% \r'
sleep 0.1
echo -ne '                   \033[1;31m  ■□□□□□□□□□10% \r'
sleep 0.1
echo -ne '                   \033[1;31m  ■■□□□□□□□□20% \r'
sleep 0.1
echo -ne '                   \033[1;33m  ■■■□□□□□□□30% \r'
sleep 0.1
echo -ne '                   \033[1;33m  ■■■■□□□□□□40% \r'
sleep 0.1
echo -ne '                   \033[1;33m  ■■■■■□□□□□50% \r'
sleep 0.1
echo -ne '                   \033[1;36m  ■■■■■■□□□□60% \r'
sleep 0.1
echo -ne '                   \033[1;36m  ■■■■■■■□□□70% \r'
sleep 0.1
echo -ne '                   \033[1;36m  ■■■■■■■■□□80% \r'
sleep 0.1
echo -ne '                   \033[1;32m  ■■■■■■■■■□90% \r'
sleep 0.1
echo -ne '                   \033[1;32m  ■■■■■■■■■■100% \r'
sleep 0.1
sleep 1
clear
kill com.vng.pubgmobile
clear
am force-stop com.vng.pubgmobile
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.UE4Game
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.vng.pubgmobile/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.UE4Game /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files /storage/emulated/0/Android/data/com.vng.pubgmobile/.files
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/.files /storage/emulated/0/Android/data/com.vng.pubgmobile/files

#mv /data/data/com.vng.pubgmobile/lib /data/data/com.vng.pubgmobile/.lib
#rm -rf /data/data/com.vng.pubgmobile/*
#mv /data/data/com.vng.pubgmobile/.lib /data/data/com.vng.pubgmobile/lib

mv /storage/emulated/0/Android/data/com.vng.pubgmobile /storage/emulated/0/Android/data/com.vng.pubgmobile1
pm clear com.vng.pubgmobile
mv /storage/emulated/0/Android/data/com.vng.pubgmobile1 /storage/emulated/0/Android/data/com.vng.pubgmobile

echo
echo 马上清除全部封号信息√
echo
echo 请修改设备ID
echo
echo 否则游戏又会在本地生成该设备的封禁信息日志

echo 开始运行第二步
am force-stop com.vng.pubgmobile
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.UE4Game
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.vng.pubgmobile/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.UE4Game /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files /storage/emulated/0/Android/data/com.vng.pubgmobile/.files
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/.files /storage/emulated/0/Android/data/com.vng.pubgmobile/files

#mv /data/data/com.vng.pubgmobile/lib /data/data/com.vng.pubgmobile/.lib
#rm -rf /data/data/com.vng.pubgmobile/*
#mv /data/data/com.vng.pubgmobile/.lib /data/data/com.vng.pubgmobile/lib

mv /storage/emulated/0/Android/data/com.vng.pubgmobile /storage/emulated/0/Android/data/com.vng.pubgmobile1
pm clear com.vng.pubgmobile
mv /storage/emulated/0/Android/data/com.vng.pubgmobile1 /storage/emulated/0/Android/data/com.vng.pubgmobile
echo 成功！开始更换ID 
echo 成功！开始更换ID 

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.vng.pubgmobile
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml

echo 开始第三步

echo 开始运行清理残留
am force-stop com.vng.pubgmobile
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.UE4Game
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.vng.pubgmobile/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.UE4Game /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files /storage/emulated/0/Android/data/com.vng.pubgmobile/.files
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/.files /storage/emulated/0/Android/data/com.vng.pubgmobile/files

#mv /data/data/com.vng.pubgmobile/lib /data/data/com.vng.pubgmobile/.lib
#rm -rf /data/data/com.vng.pubgmobile/*
#mv /data/data/com.vng.pubgmobile/.lib /data/data/com.vng.pubgmobile/lib

mv /storage/emulated/0/Android/data/com.vng.pubgmobile /storage/emulated/0/Android/data/com.vng.pubgmobile1
pm clear com.vng.pubgmobile
mv /storage/emulated/0/Android/data/com.vng.pubgmobile1 /storage/emulated/0/Android/data/com.vng.pubgmobile
echo 成功 更改ID

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   PKG=com.vng.pubgmobile
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml

echo 正在执行第4步
system_path=/private/var/mobile/Containers/Data/Application
app_path=""
for file in $system_path/*; do
    if [ -d "$file/Documents/ShadowTrackerExtra" ];then
		app_path="$file"
	fi
done

echo -e "找到pung根目录: $app_path"

# 删除 /Documents/tss_tmp
delete_path=$app_path/Documents/tss_tmp
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tdm.db
delete_path=$app_path/Documents/tdm.db
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tss_app_915c.dat
delete_path=$app_path/Documents/tss_app_915c.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tss_cs_stat2.dat
delete_path=$app_path/Documents/tss_cs_stat2.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
delete_path=$app_path/Documents/api.tpns.sh.tencent.com_IPXL3G6EADY4_xgvipiotprivateserialization.b
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tss.i.m.dat
delete_path=$app_path/Documents/tss.i.m.dat
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/tersafe.update
delete_path=$app_path/Documents/tersafe.update
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/ShadowTrackerExtra/Saved/Logs
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Logs
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/ShadowTrackerExtra/Saved/Config
delete_path=$app_path/Documents/ShadowTrackerExtra/Saved/Config
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/Caches
delete_path=$app_path/Library/Caches
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/'Saved Application State'
delete_path=$app_path/Library/'Saved Application State'
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/MidasLog
delete_path=$app_path/Library/MidasLog
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/WebKit
delete_path=$app_path/Library/WebKit
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/Cookies
delete_path=$app_path/Library/Cookies
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/'Application Support'
delete_path=$app_path/Library/'Application Support'
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/APWsjGameConfInfo.plist
delete_path=$app_path/Library/APWsjGameConfInfo.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /private/var/gg_address
delete_path=/private/var/gg_address
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Documents/sp_default.plist
delete_path=$app_path/Documents/sp_default.plist
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/'ts.records'
delete_path=$app_path/Library/'ts.records'
rm -rf $delete_path
echo "删除 $delete_path 完成"

# 删除 /Library/ts
delete_path=$app_path/Library/ts
rm -rf $delete_path
echo "删除 $delete_path 完成"

echo 正在清理...
am force-stop com.vng.pubgmobile
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.mapversion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/mapversion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SrcVersion.ini /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SrcVersion.ini
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Config /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.SaveGames /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.Paks /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/.rawdata /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/rawdata
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/.Saved /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/.ShadowTrackerExtra
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/.ShadowTrackerExtra /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.UE4Game
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/ProgramBinaryCache /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.ProgramBinaryCache /storage/emulated/0/Android/data/com.vng.pubgmobile/files/ProgramBinaryCache
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files/.UE4Game /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game

mv /storage/emulated/0/Android/data/com.vng.pubgmobile/files /storage/emulated/0/Android/data/com.vng.pubgmobile/.files
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/*
mv /storage/emulated/0/Android/data/com.vng.pubgmobile/.files /storage/emulated/0/Android/data/com.vng.pubgmobile/files


mv /storage/emulated/0/Android/data/com.vng.pubgmobile /storage/emulated/0/Android/data/com.vng.pubgmobile1
pm clear com.vng.pubgmobile
mv /storage/emulated/0/Android/data/com.vng.pubgmobile1 /storage/emulated/0/Android/data/com.vng.pubgmobile

echo 正在执行第五步

echo 0 > /proc/sys/net/nf_conntrack_max
echo 清理成功
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 清理成功
echo 0 > /proc/sys/kernel/max_lock_depth
echo 清理成功

rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/midas/log/com.vng.pubgmobile/

iptables -F 
iptables -X 
iptables -Z
ip6tables -F
ip6tables -X
ip6tables -Z

chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/comm.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/tss_ice_bolt.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.vng.pubgmobile/databases
chmod 000 //data/data/com.vng.pubgmobile/files/*tmp*
chmod 000 /data/data/com.vng.pubgmobile/files/ano_tmp
PKG=com.vng.pubgmobile
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml


echo -n "时间："
date "+%Y年%H时%M分%S秒"
echo -n "设备："
getprop ro.product.brand
echo -n "设备类型："
getprop ro.product.model

echo 修改完成，需重启系统后生效 √

echo -e "\033[41m清理成功 \033[0m"

echo 正在执行第六步
echo 0 > /proc/sys/net/nf_conntrack_max
echo 0 > /proc/sys/net/unix/max_dgram_qlen
echo 0 > /proc/sys/kernel/max_lock_depth

rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/tbslog/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/tencent/TPush/Logs/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/TGPA/Log/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/login-identifier.txt
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/cache/GameJoyRecorder/logs/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/cache/GCloudSDKLog/GCloud/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/tbslog/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/tencent/TPush/Logs/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/tencent/mobileqq/opensdk/logs/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/TGPA/Log/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PandoraV2/Logs/
rm -rf /storage/emulated/999/Android/data/com.vng.pubgmobile/files/login-identifier.txt
rm -rf /storage/emulated/0/Android/data/com.vng.pubgmobile/files/midas/log/com.vng.pubgmobile/

chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ace.r_k2.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano_app_915c.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano_cef.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano_cs_stat2.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano_emu_c2.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano_lcp.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano_r_record.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano.ano3.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/ano.i.m.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/cache.crc.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/comm.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/config2.xml.7edce36a
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/mn_cache.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/mrpcs.data
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/tdm_cache.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/tersafe.update
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/tss_base.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/tss_cfg2.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/tss_gp5.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/tss_lof.dat
chmod 0 /data/data/com.vng.pubgmobile/files/ano_tmp/tss_tcj.dat 
echo 8192 > /proc/sys/fs/inotify/max_user_watches
echo 128 > /proc/sys/fs/inotify/max_user_instances
echo 99999 > /proc/sys/fs/inotify/max_queued_events
chmod 000 /data/data/com.vng.pubgmobile/databases
chmod 000 //data/data/com.vng.pubgmobile/files/*tmp*
chmod 000 /data/data/com.vng.pubgmobile/files/ano_tmp
echo -e "\033[41m--- 清理文件成功---\033[0m"
sleep 3s


echo -e "\033[41m---正在自动为你检查一遍是否清理成功---\033[0m"
echo -e "\033[41m---请稍等马上检查完成---\033[0m"
sleep 5s

PKG=com.vng.pubgmobile
ID=$(grep $PKG /data/system/users/0/settings_ssaid.xml | awk -F'"' '{print $6}')
for i in $(seq 16)
do P=$P$(uuidgen|head -c 1|tr '-' -d)
done
sed -i s/$ID/$P/g /data/system/users/0/settings_ssaid.xml

echo -e "\033[41m---清理文件成功 退出即可---\033[0m"
echo -e "\033[41m---请更改ID重启手机在上号---\033[0m"
echo -e "\033[41m---公益频道@Czenb6---\033[0m"

 

 
            ;;
        "退出")
            break
            ;;
        *) echo "选项无效 $REPLY";;
    esac
done
sleep 3
am start -d 'coolapk.com/u/26627136' >/dev/null 2>&1

break
    else
        echo "密码错误，请重新输入"
    fi
done