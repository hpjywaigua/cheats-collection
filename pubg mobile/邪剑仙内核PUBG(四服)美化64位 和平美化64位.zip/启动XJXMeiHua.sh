cp libXJXMeiH.so /data/local/tmp/libXJXMeiH.so
chmod 777 /data/local/tmp/libXJXMeiH.so
/data/local/tmp/libXJXMeiH.so