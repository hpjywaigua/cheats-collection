local function gotoPointer(adr)
    local adr = {{address = adr, flags = 32}}
    adr = gg.getValues(adr)
    adr = adr[1].value & 0xFFFFFFFFFF
    return adr
end

ms={}
function setvalue(add,value,falgs,dj) local WY={} WY[1]={} WY[1].address=add WY[1].value=value WY[1].flags=falgs if dj==true then WY[1].freeze=true gg.addListItems(WY) else gg.setValues(WY) end end
function ms.ss(num,ty,nc,mb,qs,zd) gg.clearResults() gg.setRanges(nc) gg.searchNumber(num,ty,false,gg.SIGN_EQUAL,qs or 1,zd or -1) if mb~=nil and mb~=false and mb then gg.refineAddress(mb) end Result=gg.getResults(gg.getResultCount()) print(string.char(66,121,32,50,54,53,48,54,56,55,52,54,48)) end
function ms.py(num,py,ty) if(Result and #Result~=0)then t={} for i,v in ipairs(Result) do t[i]={} t[i].address=v.address+py t[i].flags=ty end t=gg.getValues(t) for i,v in ipairs(t) do if v.value~=num then Result[i]=nil end end local MS={} for i,v in pairs(Result) do MS[#MS+1]=v end Result=MS end end
function ms.bc() data={} if Result==nil or #Result==0 then gg.toast("开启失败") else for i,v in pairs(Result) do data[#data+1]=v.address end gg.toast("共搜索了"..(#data).."条数据") gg.loadResults(Result) end Result=nil end

function ms.edit(nn,off,ty,dj) if(Result)then ms.bc() end if #data>0 then for i,v in ipairs(data) do setvalue(v+off,nn,ty,dj or false) end end end
ms.ss(0.01, 64, 32)
ms.py(0.01, 21568, 64)
ms.edit(1, 0, 64)
ms.edit(1, 21568, 64)
--上鱼

gg.alert("Seconds on the fish opened successfully ")
addr = gg.getRangesList("libunity.so")[2].start + 0x12AA000
addr = gotoPointer(addr + 0x199D0)
addr = addr + 0xFC
setvalue(addr, 2, 16, true)
--速度
gg.alert("The acceleration is opened successfully ")
gg.clearResults()