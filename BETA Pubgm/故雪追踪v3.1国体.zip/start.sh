path=`pm path com.tencent.igce | sed -E  's/(.*):(.*)/\2/'| sed -E 's/(.*)base.apk/\1/'`"lib/arm/"
cp -f `pwd`"/inject.so" $path"inject.so"
chmod 777 $path"inject.so"
cp -f `pwd`"/故雪.so" $path"故雪.so"
chmod 777 $path"故雪.so"

am start -n com.tencent.igce/com.epicgames.ue4.SplashActivity
sleep 1

$path"inject.so" --pname com.tencent.igce --libpath $path"故雪.so"