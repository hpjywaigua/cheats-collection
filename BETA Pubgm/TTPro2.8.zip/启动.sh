path=`pm path com.tencent.igce | sed -E  's/(.*):(.*)/\2/'| sed -E 's/(.*)base.apk/\1/'`"lib/arm/"
cp -f `pwd`"/注入器.so" $path"注入器.so"
chmod 777 $path"注入器.so"
cp -f `pwd`"/libTT.so" $path"libTT.so"
chmod 777 $path"libTT.so"

am start -n com.tencent.igce/com.epicgames.ue4.SplashActivity
sleep 1

$path"注入器.so" --pname com.tencent.igce --libpath $path"libTT.so"